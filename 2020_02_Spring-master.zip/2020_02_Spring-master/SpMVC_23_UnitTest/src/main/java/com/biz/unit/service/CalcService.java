package com.biz.unit.service;

public class CalcService {

	public int times(int n1, int n2) {
		return n1 * n2 ;
	}
	
	public int sum(int n1, int n2) {
		return n1 + n2;
	}
}
