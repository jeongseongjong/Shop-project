#Final BBS 2020

## Goal
1. 단순 게시판 CRUD 구현
2. 파일 업로드 구현
	2-1. summernote의 이미지 기능 커스터마이징
3. 답글, 댓글 기능 구현
4. pagination
5. Login, 회원가입 : Spring-Security 제외 BCrypt 비밀번호 암호화만 수행


## 구현 기능
1. mybatis DB 핸들링(hybernate는 사용 X)

## 추가 기능
1. mysql과 오라클 병행작업
2. 자바 1.8의 람다 구현
3. 자바 1.8의 NIO(New IO) Stream