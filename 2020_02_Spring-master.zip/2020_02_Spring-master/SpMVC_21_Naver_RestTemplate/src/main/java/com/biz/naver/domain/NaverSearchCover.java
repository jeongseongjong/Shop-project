package com.biz.naver.domain;

import java.util.List;

public class NaverSearchCover {

	public String lastBuildDate;//": "Wed, 18 Mar 2020 13:28:44 +0900",
	public String total;//": 1028204,
	public String start;//": 1,
	public String display;//": 10,
	public List<NaverVO> items;//":
}
