package com.biz.naver.config;

public class NaverConfigSample {

	public static final String NAVER_CLINET_ID = "YOUR NAVER API ID";
	public static final String NAVER_CLINET_SECRET = "YOUR NAVER API SECRET";
}
