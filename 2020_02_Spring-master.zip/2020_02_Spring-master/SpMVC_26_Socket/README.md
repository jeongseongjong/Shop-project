## STOMP
* Streaming Text Oriented Messaging Protocol
* 문자열 지향 스트리밍 메시지 프로토콜
* 문자열로 이루어진 메시지를 주고받아서 HandShaking 을 수행하는 프로토콜

* socket을 사용한 통신에서 주로 사용되는 개념